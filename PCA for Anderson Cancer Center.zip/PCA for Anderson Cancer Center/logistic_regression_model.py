#!/usr/bin/env python
# coding: utf-8

# In[5]:


# Module 2: Logistic Regression Model

from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

class LogisticRegressionModel:
    def __init__(self):
        """
        Initializes the LogisticRegressionModel class with a logistic regression model.
        The model is set to a maximum of 10,000 iterations for convergence.
        """
        self.model = LogisticRegression(max_iter=10000)  # Logistic Regression model with increased iterations

    def train_and_evaluate(self, X, y):
        """
        Trains and evaluates the logistic regression model using the provided dataset.
        
        Args:
            X (DataFrame or array): The feature dataset.
            y (array): The target labels.

        Returns:
            accuracy (float): The accuracy score of the model on the test set.
        """
        try:
            # Step 1: Split the data into training and test sets (80% training, 20% test)
            print("Splitting data into training and testing sets...")
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
            print("Data split completed. Training on 80% of the data, testing on 20%.")
            
            # Step 2: Train the logistic regression model on the training data
            print("Training the logistic regression model...")
            self.model.fit(X_train, y_train)
            print("Model training completed.")
            
            # Step 3: Make predictions on the test data
            print("Making predictions on the test set...")
            y_pred = self.model.predict(X_test)
            
            # Step 4: Evaluate the model's accuracy on the test set
            print("Evaluating model accuracy...")
            accuracy = accuracy_score(y_test, y_pred)
            print(f"Model accuracy: {accuracy:.4f}")
            return accuracy  # Return the accuracy score
        except Exception as e:
            print(f"Error in logistic regression: {e}")  # Print error message if any exception occurs
            return None  # Return None if an error occurs during the process


