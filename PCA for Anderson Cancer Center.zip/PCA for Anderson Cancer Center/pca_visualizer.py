#!/usr/bin/env python
# coding: utf-8

# In[3]:


# Module 3: Visualization of PCA Components

import matplotlib.pyplot as plt

class PCAVisualizer:
    @staticmethod
    def plot_pca(pca_df, target):
        """
        Visualizes PCA components in a scatter plot with color encoding for the target labels.
        Args:
            pca_df (DataFrame): A DataFrame containing the PCA components.
            target (array): The target labels (0 = Malignant, 1 = Benign) used for color encoding.
        """
        try:
            print("Creating PCA scatter plot...")

            # Step 1: Initialize the plot figure
            plt.figure(figsize=(8, 6))  # Set the figure size for the plot

            # Step 2: Create the scatter plot
            scatter = plt.scatter(pca_df['PCA1'], pca_df['PCA2'], c=target, cmap='viridis', alpha=0.7)
            print("Scatter plot created.")
            
            # Step 3: Label axes and set title
            plt.xlabel('Principal Component 1')  # X-axis label
            plt.ylabel('Principal Component 2')  # Y-axis label
            plt.title('PCA of Breast Cancer Dataset')  # Title of the plot
            print("Axes labeled and title set.")
            
            # Step 4: Add color bar for target labels
            plt.colorbar(label='Target (0 = Malignant, 1 = Benign)')
            print("Color bar added.")

            # Step 5: Display the plot
            plt.show()
            print("PCA plot displayed.")
        except Exception as e:
            print(f"Error in visualization: {e}")
            return None  # Return None if any error occurs during the plotting process





