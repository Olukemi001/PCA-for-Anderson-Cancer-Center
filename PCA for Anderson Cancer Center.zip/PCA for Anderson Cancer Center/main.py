#!/usr/bin/env python
# coding: utf-8

# In[9]:


# Module 4: Main Module that Integrates All Components

from pca_processor import PCAProcessor
from logistic_regression_model import LogisticRegressionModel
from pca_visualizer import PCAVisualizer

def main():
    """
    Main function to execute the entire PCA, Logistic Regression, and Visualization workflow.
    The flow includes loading the data, applying PCA, training a logistic regression model, and visualizing PCA components.
    """
    try:
        # Step 1: Initialize PCA Processor and Load Data
        print("Initializing PCA Processor and loading the data...")
        pca_processor = PCAProcessor(n_components=2)  # Specify 2 components for PCA
        data, target = pca_processor.load_data()  # Load the breast cancer dataset
        print("Data loaded successfully.")

        print("-----------------------------------------------")

        # Step 2: Apply PCA
        print("Applying PCA to the data...")
        pca_df = pca_processor.apply_pca(data)  # Apply PCA transformation
        if pca_df is None:
            raise Exception("Failed to apply PCA.")  # If PCA fails, raise an error

        print("-----------------------------------------------")
        
        print("First two principal components:\n", pca_df.head())  # Show the first few rows of the PCA result

        print("-----------------------------------------------")

        # Step 3: Train Logistic Regression
        print("Training logistic regression model...")
        log_reg_model = LogisticRegressionModel()  # Initialize the Logistic Regression model
        accuracy = log_reg_model.train_and_evaluate(pca_df, target)  # Train and evaluate the model
        if accuracy is None:
            raise Exception("Failed to train logistic regression.")  # If training fails, raise an error
        print(f"Logistic Regression Accuracy: {accuracy:.2f}")  # Output the accuracy of the model

        print("-----------------------------------------------")

        # Step 4: Visualize PCA Components
        print("Visualizing PCA components...")
        PCAVisualizer.plot_pca(pca_df, target)  # Pass both pca_df and target as arguments

    except Exception as e:
        print(f"Error in main execution: {e}")  # Catch and print any exceptions that occur during the execution

# Run the main function
if __name__ == "__main__":
    main()  # Execute the main function when this script is run directly




