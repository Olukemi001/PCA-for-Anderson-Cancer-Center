#!/usr/bin/env python
# coding: utf-8

# In[3]:


# Module 1: PCA Implementation

from sklearn.datasets import load_breast_cancer
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import pandas as pd

class PCAProcessor:
    def __init__(self, n_components=2):
        """
        Initializes the PCAProcessor class.
        Args:
            n_components (int): Number of principal components to keep after PCA.
        """
        self.n_components = n_components  # Default to 2 components
        self.pca = None  # PCA model placeholder
        self.scaler = None  # StandardScaler placeholder
        self.pca_df = None  # DataFrame to store PCA results

    def load_data(self):
        """
        Loads the breast cancer dataset from sklearn and returns it as a DataFrame.
        
        Returns:
            df (DataFrame): A pandas DataFrame containing the cancer dataset features.
            target (array): The target array (0 = Malignant, 1 = Benign).
        """
        try:
            print("Loading breast cancer dataset...")
            cancer = load_breast_cancer()  # Load the dataset
            df = pd.DataFrame(data=cancer.data, columns=cancer.feature_names)  # Create DataFrame
            target = cancer.target  # Target values
            print("Dataset loaded successfully.")
            return df, target  # Return dataset and target
        except Exception as e:
            print(f"Error loading dataset: {e}")
            return None, None  # Return None in case of an error

    def apply_pca(self, data):
        """
        Applies PCA to the given dataset and reduces the dimensions to `n_components`.
        
        Args:
            data (DataFrame): The feature dataset to be transformed by PCA.

        Returns:
            pca_df (DataFrame): A DataFrame containing the reduced data with principal components.
        """
        try:
            print(f"Applying PCA with {self.n_components} components...")
            
            # Step 1: Scale the data before applying PCA
            self.scaler = StandardScaler()  # Initialize the scaler
            scaled_data = self.scaler.fit_transform(data)  # Scale the features
            print("Data scaling completed.")

            # Step 2: Apply PCA to the scaled data
            self.pca = PCA(n_components=self.n_components)  # Initialize PCA with the specified number of components
            pca_components = self.pca.fit_transform(scaled_data)  # Apply PCA
            
            # Step 3: Convert the PCA results into a DataFrame
            self.pca_df = pd.DataFrame(data=pca_components, columns=[f'PCA{i+1}' for i in range(self.n_components)])
            print(f"PCA applied successfully. Reduced data to {self.n_components} components.")
            return self.pca_df
        except Exception as e:
            print(f"Error in PCA processing: {e}")
            return None  # Return None in case of error


